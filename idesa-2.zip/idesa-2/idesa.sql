-- Table for document formats/templates
CREATE TABLE `tbl_format_dokumen` (
  `format_id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_format` varchar(100) NOT NULL,
  `jenis_dokumen` enum('Surat','Anggaran') NOT NULL,
  `template_file` varchar(255) NOT NULL,
  `keterangan` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`format_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for uploaded documents
CREATE TABLE `tbl_dokumen` (
  `dokumen_id` int(11) NOT NULL AUTO_INCREMENT,
  `judul_dokumen` varchar(200) NOT NULL,
  `jenis_dokumen` enum('Surat','Anggaran') NOT NULL,
  `file_dokumen` varchar(255) NOT NULL,
  `tanggal_upload` timestamp DEFAULT CURRENT_TIMESTAMP,
  `keterangan` text,
  PRIMARY KEY (`dokumen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for tourist destinations
CREATE TABLE `tbl_destinasi` (
  `destinasi_id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_destinasi` varchar(200) NOT NULL,
  `deskripsi` text NOT NULL,
  `alamat` text NOT NULL,
  `koordinat` point,
  `jam_operasional` varchar(100),
  `harga_tiket` decimal(10,2),
  `foto_utama` varchar(255),
  `status` enum('Aktif','Nonaktif') DEFAULT 'Aktif',
  PRIMARY KEY (`destinasi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for destination votes/ratings
CREATE TABLE `tbl_destinasi_vote` (
  `vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `destinasi_id` int(11) NOT NULL,
  `rating` int(1) NOT NULL,
  `komentar` text,
  `tanggal_vote` timestamp DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(45),
  PRIMARY KEY (`vote_id`),
  FOREIGN KEY (`destinasi_id`) REFERENCES `tbl_destinasi` (`destinasi_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for marketplace categories
CREATE TABLE `tbl_marketplace_kategori` (
  `kategori_id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(100) NOT NULL,
  `deskripsi` text,
  `icon` varchar(255),
  PRIMARY KEY (`kategori_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for marketplace products
CREATE TABLE `tbl_marketplace_produk` (
  `produk_id` int(11) NOT NULL AUTO_INCREMENT,
  `kategori_id` int(11) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `deskripsi` text NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `stok` int(11) NOT NULL,
  `foto_produk` varchar(255),
  `status` enum('Tersedia','Habis') DEFAULT 'Tersedia',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`produk_id`),
  FOREIGN KEY (`kategori_id`) REFERENCES `tbl_marketplace_kategori` (`kategori_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for marketplace sales
CREATE TABLE `tbl_marketplace_penjualan` (
  `penjualan_id` int(11) NOT NULL AUTO_INCREMENT,
  `produk_id` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `tanggal_penjualan` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`penjualan_id`),
  FOREIGN KEY (`produk_id`) REFERENCES `tbl_marketplace_produk` (`produk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for guest book
CREATE TABLE `tbl_buku_tamu` (
  `tamu_id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100),
  `telepon` varchar(20),
  `alamat` text,
  `pesan` text,
  `tanggal_kunjungan` date,
  `waktu_kunjungan` time,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tamu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for news categories
CREATE TABLE `tbl_berita_kategori` (
  `kategori_id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(100) NOT NULL,
  `deskripsi` text,
  PRIMARY KEY (`kategori_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for news
CREATE TABLE `tbl_berita` (
  `berita_id` int(11) NOT NULL AUTO_INCREMENT,
  `kategori_id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `gambar` varchar(255),
  `penulis` varchar(100),
  `status` enum('Draft','Published') DEFAULT 'Draft',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`berita_id`),
  FOREIGN KEY (`kategori_id`) REFERENCES `tbl_berita_kategori` (`kategori_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;