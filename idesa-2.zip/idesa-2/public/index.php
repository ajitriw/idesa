# public/.htaccess
Options -Indexes +FollowSymLinks
RewriteEngine On

# If requested file/directory exists, serve it directly
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d

# Otherwise, route through index.php
RewriteRule ^ index.php [L]