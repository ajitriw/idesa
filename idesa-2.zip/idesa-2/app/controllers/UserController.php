<?php
require_once '../app/models/User.php';

class UserController {
    private $user;
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->user = new User($this->db);
    }

    public function index() {
        $users = $this->user->getAll();
        require_once '../app/views/users/index.php';
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->user->username = $_POST['username'];
            $this->user->email = $_POST['email'];
            $this->user->password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            
            if($this->user->create()) {
                header("Location: index.php?controller=user&action=index");
            }
        } else {
            require_once '../app/views/users/create.php';
        }
    }

    public function edit() {
        if(isset($_GET['id'])) {
            $userData = $this->user->getById($_GET['id']);
            if($_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->user->id = $_GET['id'];
                $this->user->username = $_POST['username'];
                $this->user->email = $_POST['email'];
                
                if($this->user->update()) {
                    header("Location: index.php?controller=user&action=index");
                }
            } else {
                require_once '../app/views/users/edit.php';
            }
        }
    }
}